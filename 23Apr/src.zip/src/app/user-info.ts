export interface UserInfo {
    userId?:string,
    displayName?:string,
    email?:string,
    password?:string,
    role?:number
}
