export interface HotelInfo {
    hotelId?:string,
    hotelname?:string,
    email?:string,
    password?:string,
    type?:number
}
