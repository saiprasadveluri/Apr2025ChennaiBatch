import { Component } from '@angular/core';
import { SmsNotifiedService } from '../sms-notified.service';
import { EmailNotifiedService } from '../email-notified.service';
import { SMTPDataObject } from '../smtp-data-object';
@Component({
  selector: 'app-downloadmanager',
  templateUrl: './downloadmanager.component.html',
  styleUrls: ['./downloadmanager.component.css']
})
export class DownloadmanagerComponent {

  smsMSG: string = "";

  emailData?: SMTPDataObject;
  constructor (private smsService: SmsNotifiedService, 
    private emailService: EmailNotifiedService){}

  DownloadFile(){
    console.log("Download")
    const msg = 'File DWNW';
    this.smsMSG = " DOWNLOAD IS READY"

    this.emailData = new SMTPDataObject('TMKC', " PKMKB", 'TMC :' + msg )

    this.smsService.notify(msg);
    this.emailService.notify(msg);
  }
}
