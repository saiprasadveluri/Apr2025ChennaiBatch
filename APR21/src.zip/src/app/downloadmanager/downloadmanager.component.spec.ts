import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadmanagerComponent } from './downloadmanager.component';

describe('DownloadmanagerComponent', () => {
  let component: DownloadmanagerComponent;
  let fixture: ComponentFixture<DownloadmanagerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DownloadmanagerComponent]
    });
    fixture = TestBed.createComponent(DownloadmanagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
