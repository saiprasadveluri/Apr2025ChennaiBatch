import { TestBed } from '@angular/core/testing';

import { EmailNotifiedService } from './email-notified.service';

describe('EmailNotifiedService', () => {
  let service: EmailNotifiedService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmailNotifiedService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
