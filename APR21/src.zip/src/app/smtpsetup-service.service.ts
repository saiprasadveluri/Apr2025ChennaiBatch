import { Injectable } from '@angular/core';
import { SMTPDataObject } from './smtp-data-object';
@Injectable({
  providedIn: 'root'
})
export class SMTPsetupServiceService {
  send(data: SMTPDataObject) 
  {
      console.log("Sending Email with : ")

      console.log('TO  :', data.to);
      console.log('Subject ', data.subject);
      console.log('Body : ', data.body);

  }
  
}
