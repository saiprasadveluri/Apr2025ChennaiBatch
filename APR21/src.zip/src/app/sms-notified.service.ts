import { Injectable } from '@angular/core';
import { NotificationService } from './notification.service';
@Injectable({
  providedIn: 'root'
})
export class SmsNotifiedService  extends NotificationService{
  override notify(message: string){
    super.notify(message);
    console.log('SMS sent:', message);
  }
  
}
