import { Injectable } from '@angular/core';
import { NotificationService } from './notification.service';
import { SMTPDataObject } from './smtp-data-object';
import { SMTPsetupServiceService } from './smtpsetup-service.service';
@Injectable({
  providedIn: 'root'
})
export class EmailNotifiedService extends NotificationService{


  constructor(private smtp: SMTPsetupServiceService){ super();}
    override notify(message: string) {
        super.notify(message);

        const emailData = new SMTPDataObject('useer@abc.com',  'buy a bag', 'Buy a big very big bag  :' + message);


        this.smtp.send(emailData);
    }

    
}
