"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SMTPDataObject = void 0;
var SMTPDataObject = /** @class */ (function () {
    function SMTPDataObject(to, subject, body) {
        this.to = to;
        this.subject = subject;
        this.body = body;
    }
    return SMTPDataObject;
}());
exports.SMTPDataObject = SMTPDataObject;
var a = new SMTPDataObject("shivam", "buying a laptop", " please but a laptop");
