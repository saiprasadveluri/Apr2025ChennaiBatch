import { TestBed } from '@angular/core/testing';

import { SMTPsetupServiceService } from './smtpsetup-service.service';

describe('SMTPsetupServiceService', () => {
  let service: SMTPsetupServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SMTPsetupServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
