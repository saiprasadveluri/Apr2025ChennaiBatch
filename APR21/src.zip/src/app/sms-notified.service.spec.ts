import { TestBed } from '@angular/core/testing';

import { SmsNotifiedService } from './sms-notified.service';

describe('SmsNotifiedService', () => {
  let service: SmsNotifiedService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SmsNotifiedService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
