export class SMTPDataObject{
    constructor(public to:string, public subject:string, public body:string){}
}
